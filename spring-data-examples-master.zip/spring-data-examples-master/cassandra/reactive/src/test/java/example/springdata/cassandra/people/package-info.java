/**
 * Package showing usage of Spring Data Cassandra Reactive Repositories and reactive Cassandra template.
 */
package example.springdata.cassandra.people;

